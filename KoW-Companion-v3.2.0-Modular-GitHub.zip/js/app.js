const DEFAULT_OFFICERS=[{"name": "S7 Roisin", "orv": 600, "srv": 300}, {"name": "S7 Barbara", "orv": 600, "srv": 300}, {"name": "S7 Romana", "orv": 500, "srv": 250}, {"name": "S7 Liora", "orv": 500, "srv": 250}, {"name": "S7 Stella", "orv": 416, "srv": 208}, {"name": "S7 Klara", "orv": 416, "srv": 208}, {"name": "S7 Code", "orv": 346, "srv": 173}, {"name": "S7 Kamila", "orv": 346, "srv": 173}, {"name": "S6 Regina", "orv": 289, "srv": 144}, {"name": "S6 Veronica", "orv": 289, "srv": 144}, {"name": "S6 Silverhand", "orv": 240, "srv": 120}, {"name": "S6 Red Queen", "orv": 240, "srv": 120}, {"name": "S6 Samantha", "orv": 200, "srv": 100}, {"name": "S6 Saoirse", "orv": 200, "srv": 100}, {"name": "S6 Emily", "orv": 167, "srv": 84}, {"name": "S6 Zoya", "orv": 167, "srv": 84}];
let OFFICERS=[];
const STAR=[0,500,1500,8000,33000,98000], SK=[10,10,15,15,30,30,40,40,45,45,50,50,75,75,80,80], XP=[50,100,500,1000,5000,10000,20000,50000];
const MAXXP=199646700, MAXBADGE=1600, MAXSTAR=98000;
let skillState=Array(16).fill(false);
const $=x=>document.getElementById(x), fmt=x=>Math.max(0,Math.round(+x||0)).toLocaleString(), pct=(a,b)=>Math.min(100,Math.max(0,a/b*100));

function deepClone(v){return JSON.parse(JSON.stringify(v))}
function normaliseOfficer(o){
 return {
   name:String(o.name||'').trim(),
   season:String(o.season||((String(o.name||'').match(/^S\d+/)||[''])[0])).trim(),
   orv:Math.max(0,Math.round(Number(o.orv)||0)),
   srv:Math.max(0,Math.round(Number(o.srv)||0)),
   notes:String(o.notes||'').trim()
 };
}
function loadOfficerDatabase(){
 try{
   const saved=JSON.parse(localStorage.getItem('kow_officer_database_v31')||'null');
   OFFICERS=Array.isArray(saved)&&saved.length?saved.map(normaliseOfficer):DEFAULT_OFFICERS.map(normaliseOfficer);
 }catch(e){OFFICERS=DEFAULT_OFFICERS.map(normaliseOfficer)}
}
function saveOfficerDatabase(){
 const errors=validateOfficerDatabase();
 if(errors.length){renderDbValidation(errors);alert('Fix database validation issues before saving.');return false}
 localStorage.setItem('kow_officer_database_v31',JSON.stringify(OFFICERS));
 renderOfficerOptions();
 renderDatabase();
 alert('Officer database saved.');
 return true;
}
function validateOfficerDatabase(list=OFFICERS){
 const errors=[],seen=new Set();
 list.forEach((o,i)=>{
   const row=i+1,key=(o.name||'').trim().toLowerCase();
   if(!key)errors.push(`Row ${row}: Officer name is required.`);
   if(key&&seen.has(key))errors.push(`Row ${row}: Duplicate officer name "${o.name}".`);
   if(key)seen.add(key);
   if(!Number.isInteger(Number(o.orv))||Number(o.orv)<=0)errors.push(`Row ${row}: ORV must be a whole number above zero.`);
   if(!Number.isInteger(Number(o.srv))||Number(o.srv)<=0)errors.push(`Row ${row}: SRV must be a whole number above zero.`);
 });
 return errors;
}
function renderDbValidation(errors=validateOfficerDatabase()){
 const host=$('dbValidation');if(!host)return;
 host.innerHTML=errors.length?'<b>Validation issues:</b><br>'+errors.join('<br>'):'Database validation passed.';
}
function renderOfficerOptions(selectedName){
 const select=$('officerSelect');if(!select)return;
 const previous=selectedName||select.options[select.selectedIndex]?.textContent||'S7 Liora';
 select.innerHTML='';
 OFFICERS.forEach((o,i)=>{
   const op=document.createElement('option');op.value=i;op.textContent=o.name;select.appendChild(op);
 });
 const idx=OFFICERS.findIndex(o=>o.name===previous);
 select.value=idx>=0?idx:Math.min(3,OFFICERS.length-1);
 calc();
}
function escapeHtml(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function renderSeasonFilter(){
 const host=$('dbSeason');if(!host)return;
 const current=host.value;
 const seasons=[...new Set(OFFICERS.map(o=>o.season).filter(Boolean))].sort();
 host.innerHTML='<option value="">All seasons</option>'+seasons.map(s=>`<option>${escapeHtml(s)}</option>`).join('');
 host.value=current;
}
function renderDatabase(){
 const host=$('dbRows');if(!host)return;
 renderSeasonFilter();
 const q=($('dbSearch')?.value||'').trim().toLowerCase();
 const season=$('dbSeason')?.value||'';
 const rows=OFFICERS.map((o,i)=>({...o,_i:i})).filter(o=>(!q||o.name.toLowerCase().includes(q))&&(!season||o.season===season));
 host.innerHTML=rows.map(o=>`
 <tr data-index="${o._i}">
  <td><input data-field="name" value="${escapeHtml(o.name)}"></td>
  <td><input data-field="season" value="${escapeHtml(o.season)}"></td>
  <td><input data-field="orv" type="number" min="1" step="1" inputmode="numeric" value="${o.orv}"></td>
  <td><input data-field="srv" type="number" min="1" step="1" inputmode="numeric" value="${o.srv}"></td>
  <td><input data-field="notes" value="${escapeHtml(o.notes)}"></td>
  <td class="actions"><button data-copy>Copy</button><button data-delete>Delete</button></td>
 </tr>`).join('');
 host.querySelectorAll('input').forEach(input=>input.addEventListener('input',e=>{
   const tr=e.target.closest('tr'),i=Number(tr.dataset.index),field=e.target.dataset.field;
   OFFICERS[i][field]=(field==='orv'||field==='srv')?Number(e.target.value):e.target.value;
   renderDbValidation();
 }));
 host.querySelectorAll('[data-copy]').forEach(btn=>btn.addEventListener('click',e=>{
   const i=Number(e.target.closest('tr').dataset.index);
   OFFICERS.splice(i+1,0,{...OFFICERS[i],name:OFFICERS[i].name+' Copy'});
   renderDatabase();renderOfficerOptions();
 }));
 host.querySelectorAll('[data-delete]').forEach(btn=>btn.addEventListener('click',e=>{
   const i=Number(e.target.closest('tr').dataset.index);
   if(OFFICERS.length<=1){alert('At least one officer is required.');return}
   OFFICERS.splice(i,1);renderDatabase();renderOfficerOptions();
 }));
 renderDbValidation();
}
function csvEscape(v){return `"${String(v??'').replaceAll('"','""')}"`}
function exportOfficerCsv(){
 const rows=[['Officer Name','Season','ORV per Badge','SRV per Exclusive Star','Notes'],...OFFICERS.map(o=>[o.name,o.season,o.orv,o.srv,o.notes])];
 const text=rows.map(r=>r.map(csvEscape).join(',')).join('\n');
 const blob=new Blob([text],{type:'text/csv'});
 const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='officers.csv';a.click();URL.revokeObjectURL(a.href);
}
function parseOfficerCsv(text){
 const rows=[];let row=[],cell='',quoted=false;
 for(let i=0;i<text.length;i++){
   const c=text[i],n=text[i+1];
   if(c==='"'&&quoted&&n==='"'){cell+='"';i++}
   else if(c==='"')quoted=!quoted;
   else if(c===','&&!quoted){row.push(cell);cell=''}
   else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&n==='\n')i++;row.push(cell);if(row.some(x=>x.trim()!==''))rows.push(row);row=[];cell=''}
   else cell+=c;
 }
 row.push(cell);if(row.some(x=>x.trim()!==''))rows.push(row);
 return rows.slice(1).map(r=>normaliseOfficer({name:r[0],season:r[1],orv:r[2],srv:r[3],notes:r[4]}));
}
function importOfficerCsv(file){
 if(!file)return;
 const reader=new FileReader();
 reader.onload=()=>{
   const parsed=parseOfficerCsv(reader.result);
   const errors=validateOfficerDatabase(parsed);
   if(errors.length){renderDbValidation(errors);alert('CSV import failed validation.');return}
   OFFICERS=parsed;localStorage.setItem('kow_officer_database_v31',JSON.stringify(OFFICERS));
   renderDatabase();renderOfficerOptions();alert('Officer CSV imported.');
 };
 reader.readAsText(file);
}
function bindDatabaseControls(){
 $('dbSearch')?.addEventListener('input',renderDatabase);
 $('dbSeason')?.addEventListener('change',renderDatabase);
 $('dbAdd')?.addEventListener('click',()=>{OFFICERS.push({name:'New Officer',season:'S8',orv:1,srv:1,notes:''});renderDatabase();renderOfficerOptions('New Officer')});
 $('dbSave')?.addEventListener('click',saveOfficerDatabase);
 $('dbExport')?.addEventListener('click',exportOfficerCsv);
 $('dbImport')?.addEventListener('change',e=>{importOfficerCsv(e.target.files[0]);e.target.value=''});
 $('dbRestore')?.addEventListener('click',()=>{if(confirm('Restore the default officer database?')){OFFICERS=DEFAULT_OFFICERS.map(normaliseOfficer);localStorage.setItem('kow_officer_database_v31',JSON.stringify(OFFICERS));renderDatabase();renderOfficerOptions('S7 Liora')}});
}
function loadAppearance(){
 const name=localStorage.getItem('kow_app_name_v31');
 if(name){$('appName').value=name;$('appTitle').textContent=name;document.title=name}
 const bg=localStorage.getItem('kow_bg_v31');
 if(bg)document.body.style.backgroundImage=`linear-gradient(rgba(0,0,0,.45),rgba(0,0,0,.78)),url('${bg}')`;
}
function bindAppearance(){
 $('appName')?.addEventListener('input',e=>{const name=e.target.value||'GODS OF WAR 371';localStorage.setItem('kow_app_name_v31',name);$('appTitle').textContent=name;document.title=name});
 $('backgroundPicker')?.addEventListener('change',e=>{const file=e.target.files[0];if(!file)return;const r=new FileReader();r.onload=()=>{localStorage.setItem('kow_bg_v31',r.result);document.body.style.backgroundImage=`linear-gradient(rgba(0,0,0,.45),rgba(0,0,0,.78)),url('${r.result}')`};r.readAsDataURL(file)});
 $('resetAppearance')?.addEventListener('click',()=>{localStorage.removeItem('kow_app_name_v31');localStorage.removeItem('kow_bg_v31');location.reload()});
}

function init(){
 loadOfficerDatabase();renderOfficerOptions('S7 Liora');
 SK.forEach((c,i)=>{let b=document.createElement('button');b.className='skill';b.textContent=`${i+1} · ${c}`;b.onclick=()=>{skillState[i]=!skillState[i];b.classList.toggle('active');calc()};$('skills').appendChild(b)});
 XP.forEach(v=>{let d=document.createElement('div');d.className='card';d.style.margin='0';d.innerHTML=`<label>${v.toLocaleString()} XP</label><input id="xp${v}" type="number" value="0">`;$('xpInputs').appendChild(d)});
 bindDatabaseControls();bindAppearance();loadAppearance();renderDatabase();
 document.querySelectorAll('input,select').forEach(e=>e.addEventListener('input',calc));
 
['currentLevel','targetLevel'].forEach(id=>{
 const el=$(id);
 el.addEventListener('blur',()=>{
   let value=Math.round(Number(el.value));
   if(!Number.isFinite(value)) value=id==='currentLevel'?1:70;
   value=Math.max(1,Math.min(70,value));
   el.value=value;
   if(+$('targetLevel').value < +$('currentLevel').value){
     $('targetLevel').value=$('currentLevel').value;
   }
   calc();
 });
});

 document.querySelectorAll('.tab').forEach(t=>t.onclick=()=>{document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));$(t.dataset.screen).classList.add('active');
['currentLevel','targetLevel'].forEach(id=>{
 const el=$(id);
 el.addEventListener('blur',()=>{
   let value=Math.round(Number(el.value));
   if(!Number.isFinite(value)) value=id==='currentLevel'?1:70;
   value=Math.max(1,Math.min(70,value));
   el.value=value;
   if(+$('targetLevel').value < +$('currentLevel').value){
     $('targetLevel').value=$('currentLevel').value;
   }
   calc();
 });
});

 document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));t.classList.add('active')});
 $('saveBtn').onclick=save; load(); calc();
}
function cumulativeXpForLevel(level){
 level=Math.max(1,Math.min(70,Number(level)||1));
 if(level<=1)return 0;
 if(level<=40)return 5806700*((level-1)/39);
 if(level<=50)return 5806700+16960000*((level-40)/10);
 if(level<=60)return 22766700+53430000*((level-50)/10);
 return 76196700+123450000*((level-60)/10);
}
function calc(){
 let o=OFFICERS[+$('officerSelect').value]||OFFICERS[0]||{name:'Officer',orv:0,srv:0};$('orv').value=o.orv;$('srv').value=o.srv;$('dOfficer').textContent=o.name;
 let cs=+$('currentStar').value,ts=+$('targetStar').value;if(ts<cs){ts=cs;$('targetStar').value=ts}
 let invested=STAR[cs];
 let legendaryHeld=+$('ls1').value*110 + +$('ls2').value*420 + +$('ls3').value*960;
 let srvHeld=+$('srvHeld').value;
 let exclusiveFromSrv=o.srv>0?Math.floor(srvHeld/o.srv):0;
 let srvRemainder=o.srv>0?srvHeld-(exclusiveFromSrv*o.srv):srvHeld;
 let officerStarsFromSrv=exclusiveFromSrv*110;
 let inv=legendaryHeld+officerStarsFromSrv;
 let available=invested+inv;
 let needed=Math.max(0,STAR[ts]-available);
 $('exclusiveFromSrv').textContent=fmt(exclusiveFromSrv);
 $('officerStarsFromSrv').textContent=fmt(officerStarsFromSrv);
 $('srvRemainder').textContent=fmt(srvRemainder);
 $('starInvested').textContent=fmt(invested);$('starHeld').textContent=fmt(inv);$('starRemaining').textContent=fmt(needed);$('starBar').style.width=pct(available,STAR[ts]||1)+'%';
 let bInv=+$('badgeInv').value;
 let bSpent=($('unlocked').checked?10:0)+skillState.reduce((s,on,i)=>s+(on?SK[i]:0),0)+ +$('training').value*5;
 let orvInv=+$('orvHeld').value;
 let badgesFromOrv=o.orv>0?Math.floor(orvInv/o.orv):0;
 let orvRemainder=o.orv>0?orvInv-(badgesFromOrv*o.orv):orvInv;
 let bAvail=bSpent+bInv+badgesFromOrv;
 let bRem=Math.max(0,MAXBADGE-bAvail);
 let orvReq=bRem*o.orv;
 $('trainingLabel').textContent=$('training').value;
 $('badgeInvested').textContent=fmt(bSpent);
 $('badgeHeld').textContent=fmt(bInv);
 $('badgesFromOrv').textContent=fmt(badgesFromOrv)+' badges · '+fmt(orvRemainder)+' ORV left';
 $('badgeRequired').textContent=fmt(bRem);
 $('orvNeeded').textContent=fmt(orvReq);
 $('badgeBar').style.width=pct(bAvail,MAXBADGE)+'%';
 let xp=0;XP.forEach(v=>xp+=+(($('xp'+v)||{value:0}).value)*v);
 let currentRaw=$('currentLevel').value;
 let targetRaw=$('targetLevel').value;
 let currentLevel=currentRaw===''?1:Math.max(1,Math.min(70,Number(currentRaw)));
 let targetLevel=targetRaw===''?70:Math.max(1,Math.min(70,Number(targetRaw)));
 if(targetLevel<currentLevel) targetLevel=currentLevel;
 let xpRequired=Math.max(0,cumulativeXpForLevel(targetLevel)-cumulativeXpForLevel(currentLevel));
 let xpShort=Math.max(0,xpRequired-xp);
 $('xpTotal').textContent=fmt(xp);
 $('xpRequiredLevels').textContent=fmt(xpRequired);
 $('xpRemaining').textContent=fmt(xpShort);
 $('xpBar').style.width=pct(xp,xpRequired||1)+'%';
 let overall=(pct(available,MAXSTAR)+pct(bAvail,MAXBADGE)+pct(xp,MAXXP))/3;$('overall').textContent=overall.toFixed(1)+'%';$('overallBar').style.width=overall+'%';
 $('dStars').textContent=fmt(available);$('dStarsRem').textContent=fmt(MAXSTAR-available);$('dBadges').textContent=fmt(badgesFromOrv);$('dBadgesRem').textContent=fmt(bRem);$('dXp').textContent=fmt(xp);$('dXpBar').style.width=pct(xp,xpRequired||1)+'%';
 planner(o,cs,invested,inv,bSpent,bInv,xp,+$('orvHeld').value,xpRequired);
}
function planner(o,cs,invested,inv,bSpent,bInv,xp,orvInv,xpRequiredSelected){
 let g=$('goal').value, starReq=0,badgeReq=0,xpReq=0;
 if(g==='next')starReq=STAR[Math.min(5,cs+1)]; else if(g==='five'||g==='max')starReq=MAXSTAR;
 if(g==='skills')badgeReq=700; else if(g==='training'||g==='max')badgeReq=MAXBADGE;
 if(g==='max')xpReq=xpRequiredSelected;
 let rows=[
 ['Legendary Stars',Math.max(0,starReq-invested),inv],
 ['Officer Badges',Math.max(0,badgeReq-bSpent),bInv],
 ['Officer Badges From Held ORV',Math.max(0,badgeReq-bSpent),Math.floor(orvInv/o.orv)],
 ['Officer Readiness Vouchers',Math.max(0,badgeReq-bSpent)*o.orv,orvInv],
 ['Exclusive Stars',Math.ceil(Math.max(0,starReq-invested)/110),0],
 ['Star Readiness Vouchers',Math.ceil(Math.max(0,starReq-invested)/110)*o.srv,0],
 ['Officer XP',Math.max(0,xpReq),xp]];
 $('rows').innerHTML=rows.map(r=>`<tr><td>${r[0]}</td><td>${fmt(r[1])}</td><td>${fmt(r[2])}</td><td>${fmt(Math.max(0,r[1]-r[2]))}</td></tr>`).join('');
}
function save(){let d={officer:$('officerSelect').value,current:$('currentStar').value,target:$('targetStar').value,ls1:$('ls1').value,ls2:$('ls2').value,ls3:$('ls3').value,srvHeld:$('srvHeld').value,unlocked:$('unlocked').checked,skills:skillState,training:$('training').value,badgeInv:$('badgeInv').value,orvHeld:$('orvHeld').value,goal:$('goal').value,currentLevel:$('currentLevel').value,targetLevel:$('targetLevel').value,xp:{}};XP.forEach(v=>d.xp[v]=$('xp'+v).value);localStorage.setItem('gow371_proto',JSON.stringify(d));alert('Saved on this device')}
function load(){let r=localStorage.getItem('gow371_proto');if(!r)return;try{let d=JSON.parse(r);$('officerSelect').value=d.officer??3;$('currentStar').value=d.current??0;$('targetStar').value=d.target??5;$('ls1').value=d.ls1??0;$('ls2').value=d.ls2??0;$('ls3').value=d.ls3??0;$('srvHeld').value=d.srvHeld??0;$('unlocked').checked=!!d.unlocked;$('training').value=d.training??0;$('badgeInv').value=d.badgeInv??0;$('orvHeld').value=d.orvHeld??0;$('goal').value=d.goal??'max';$('currentLevel').value=d.currentLevel??1;$('targetLevel').value=d.targetLevel??70;skillState=d.skills??skillState;document.querySelectorAll('.skill').forEach((b,i)=>b.classList.toggle('active',!!skillState[i]));XP.forEach(v=>$('xp'+v).value=d.xp?.[v]??0)}catch(e){}}
init();
